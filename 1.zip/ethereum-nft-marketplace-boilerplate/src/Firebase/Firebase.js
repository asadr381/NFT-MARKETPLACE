import { initializeApp, getApps, getApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
    apiKey: "AIzaSyCidFMIP-tcEWJB32HTKXi6lq25iLMVhwE",
    authDomain: "fypproject-63fe3.firebaseapp.com",
    projectId: "fypproject-63fe3",
    storageBucket: "fypproject-63fe3.appspot.com",
    messagingSenderId: "262730629416",
    appId: "1:262730629416:web:a5955fbbd89b5a3218501d",
    measurementId: "G-5MZ3YFN2D1"
};

// Initialize Firebase
const firebaseApp = !getApps().length
  ? initializeApp(firebaseConfig)
  : getApp();
const db = getFirestore();
const storage = getStorage();
const auth = getAuth(firebaseApp);

export { db, storage, auth };
